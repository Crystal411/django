from django.apps import AppConfig


class MilitaryshowConfig(AppConfig):
    name = 'MilitaryShow'
